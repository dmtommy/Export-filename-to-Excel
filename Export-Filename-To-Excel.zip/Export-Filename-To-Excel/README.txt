*Make sure that you have install openpyxl and pandas library for Excel.

*You can install them through these commands.

pip install openpyxl
pip install pandas